﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabajoPar___2
{
    internal class Program
    {       
       static void Main(string[] args)
       {
                const int dias = 7;
                double[] ventas = new double[dias];
                bool salir = false;

                while (!salir)
                {
                    Console.WriteLine("Menu de Ventas");
                    Console.WriteLine("1. Ingresar ventas");
                    Console.WriteLine("2. Calcular total de ventas");
                    Console.WriteLine("3. Mostrar día con la venta más alta");
                    Console.WriteLine("4. Salir");
                    Console.Write("Ingrese una opción: ");
                    string opcion = Console.ReadLine();

                    switch (opcion)
                    {
                        case "1":
                            Funciones.VentasNegocio.IngresarVentas(ventas);
                            break;
                        case "2":
                            double totalVendido = Funciones.VentasNegocio.CalcularTotalVendido(ventas);
                            Console.WriteLine($"Total vendido: {totalVendido}");
                            break;
                        case "3":
                            int diaMaxVenta = Funciones.VentasNegocio.EncontrarDiaMaxVenta(ventas);
                            Console.WriteLine($"Día con la venta más alta: {diaMaxVenta + 1}");
                            break;
                        case "4":
                            salir = true;
                            break;
                        default:
                            Console.WriteLine("Opción no válida, intente de nuevo.");
                            break;
                    }
                    Console.WriteLine();
                }
          
       }
    }
}