﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabajoPar___2
{
    internal class Funciones
    {
        public static class VentasNegocio
        {
            public static void IngresarVentas(double[] ventas)
            {
                for (int i = 0; i < ventas.Length; i++)
                {
                    Console.Write($"Ingrese las ventas del día {i + 1}: ");
                    ventas[i] = Convert.ToDouble(Console.ReadLine());
                }
            }

            public static double CalcularTotalVendido(double[] ventas)
            {
                double total = 0;
                foreach (var venta in ventas)
                {
                    total += venta;
                }
                return total;
            }

            public static int EncontrarDiaMaxVenta(double[] ventas)
            {
                int diaMax = 0;
                double maxVenta = ventas[0];

                for (int i = 1; i < ventas.Length; i++)
                {
                    if (ventas[i] > maxVenta)
                    {
                        maxVenta = ventas[i];
                        diaMax = i;
                    }
                }

                return diaMax;
            }
        }
    }
}