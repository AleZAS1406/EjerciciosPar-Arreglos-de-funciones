﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabajoPar___3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool continuar = true;

            while (continuar)
            {
                Console.WriteLine("Ingrese una temperatura en grados Celsius:");
                double tempCelsius;
                if (double.TryParse(Console.ReadLine(), out tempCelsius))
                {
                    Funciones.AgregarTemperatura(tempCelsius);
                    Funciones.ConvertirTemperaturas(tempCelsius);
                }
                else
                {
                    Console.WriteLine("Por favor ingrese un número válido.");
                }

                Funciones.MostrarListas();

                Console.WriteLine("¿Desea eliminar alguna temperatura de las listas? (s/n)");
                if (Console.ReadLine().ToLower() == "s")
                {
                    Funciones.EliminarTemperatura();
                }

                Console.WriteLine("¿Desea agregar otra temperatura? (s/n)");
                continuar = Console.ReadLine().ToLower() == "s";
            }

            Console.WriteLine("Programa finalizado.");
        }
    }
}
    