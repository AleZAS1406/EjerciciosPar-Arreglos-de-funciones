﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabajoPar___3
{
    public static class Funciones
    {
        private static List<double> temperaturasCelsius = new List<double>();
        private static List<double> temperaturasFahrenheit = new List<double>();
        private static List<double> temperaturasKelvin = new List<double>();

        public static void AgregarTemperatura(double celsius)
        {
            temperaturasCelsius.Add(celsius);
        }

        public static void ConvertirTemperaturas(double celsius)
        {
            double fahrenheit = CelsiusAFahrenheit(celsius);
            double kelvin = CelsiusAKelvin(celsius);

            temperaturasFahrenheit.Add(fahrenheit);
            temperaturasKelvin.Add(kelvin);

            Console.WriteLine($"La temperatura {celsius} °C es equivalente a {fahrenheit} °F y {kelvin} K.");
        }

        public static double CelsiusAFahrenheit(double celsius)
        {
            return (celsius * 9 / 5) + 32;
        }

        public static double CelsiusAKelvin(double celsius)
        {
            return celsius + 273.15;
        }

        public static void MostrarListas()
        {
            Console.WriteLine("\nTemperaturas en Celsius:");
            MostrarLista(temperaturasCelsius);
            Console.WriteLine("Temperaturas en Fahrenheit:");
            MostrarLista(temperaturasFahrenheit);
            Console.WriteLine("Temperaturas en Kelvin:");
            MostrarLista(temperaturasKelvin);
        }

        private static void MostrarLista(List<double> lista)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {lista[i]}");
            }
        }

        public static void EliminarTemperatura()
        {
            Console.WriteLine("Seleccione el número de la temperatura que desea eliminar de las listas:");
            MostrarLista(temperaturasCelsius);

            int indice;
            if (int.TryParse(Console.ReadLine(), out indice) && indice > 0 && indice <= temperaturasCelsius.Count)
            {
                temperaturasCelsius.RemoveAt(indice - 1);
                temperaturasFahrenheit.RemoveAt(indice - 1);
                temperaturasKelvin.RemoveAt(indice - 1);

                Console.WriteLine("Temperatura eliminada exitosamente.");
            }
            else
            {
                Console.WriteLine("Número inválido.");
            }
        }
    }
}

